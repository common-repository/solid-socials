=== solid_socials ===
Contributors: rorykermack
Tags: social media, sharing
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is a simple social sharing plugin which floats to the side of your posts and pages

== Description ==

solid_socials is a simple social sharing plugin which allows visitors to share your content via social media.
It has settings to adjust which icons will be presented as well as its positioning. It is designed to hide on mobile as so not to get in the way of the content.


== Installation ==

This section describes how to install the plugin and get it working.



1. Upload `solid_socials` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Confirm your settings through the 'Settings' menu in WordPress

== Screenshots ==

1. This screen shot shows the plugin in action "http://codeanthology.com/wp-content/uploads/2013/12/Screen-Shot-2013-12-08-at-7.11.40-PM.png"

== Changelog ==

= 0.5 =
* release

