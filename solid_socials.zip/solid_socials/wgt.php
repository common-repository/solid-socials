<?php
$options = get_option('solid_socials');

$twitterHandle = $options['twitter_handle'];
$headerHeight = $options['header_height'];
$position = $options['position'];
$display = $options['display_options'];
$fb_option = $options['fb_option'];
$link_love = $options['link_love'];



?>
<link rel="stylesheet" href="<?php echo home_url(); ?>/wp-content/plugins/solid_socials/style.css"/>
<script src="//platform.linkedin.com/in.js" type="text/javascript"></script>
     
<div class="solid_socials <?php if($position == 1) {echo 'solid_socials_left';} else {echo 'solid_socials_right';} ?>" style="top:<?php echo $headerHeight."px"; ?>">
    <!-- Facebook -->
    <div id="fb-root"></div>
    <ul>
	<?php if(in_array('facebook',$display)){ ?>
	<li>
	    <span class="solid_socials_btn facebookBtn">
		<span class="solid_socials_btnInner">
			<?php if($fb_option == 'like'){ ?>
		                     <div class="fb-like" data-layout="box_count" data-action="like" data-show-faces="false" data-share="false"></div>
			<?php }
			else { ?>
				    <div class="fb-share-button" data-href="" data-type="box_count"></div>
				   <?php } ?>
		</span>
	    </span>
	</li>
	<?php } ?>
	<!-- Twitter -->
	<?php if(in_array('twitter',$display)){ ?>
	<li>
	    <span class="solid_socials_btn twitterBtn">
		<span class="solid_socials_btnInner">
		    <a href="https://twitter.com/share" class="twitter-share-button" data-via="<?php echo $twitterHandle; ?>" data-count="vertical"  data-text="">Tweet</a> 
		</span>
	    </span>
	</li>
	<?php } ?>
	<!-- Stumbleupon -->
	<?php if(in_array('stumbleupon',$display)){ ?>
	<li>
	    <span class="solid_socials_btn stumbleBtn">
		<span class="solid_socials_btnInner">
		     <su:badge layout="5"></su:badge>
		</span>
	    </span>
	</li>
	<?php } ?>
	<!-- linkedIn -->
	<?php if(in_array('linkedIn',$display)){ ?>
	<li>
	    <span class="solid_socials_btn linkedInBtn">
		<span class="solid_socials_btnInner">
		    <script type="IN/Share" data-counter="top"></script>
		</span>
	    </span>
	</li>
	<?php } ?>
	<!-- Google + -->
	<?php if(in_array('googleplus',$display)){ ?>
	<li>
	    <span class="solid_socials_btn googleplusBtn">
		<span class="solid_socials_btnInner">
		    <div class="g-plusone" data-size="tall" ></div>
		</span>
	    </span>
	</li>
	<?php } ?>
    </ul>
    <span id="solid_credits">
	<a <?php if($link_love == '1') echo 'href="http://codeanthology.com/solid-socials" target="_blank"'; ?>>SOLID</a>
	<span id="solid_hide"></span>
    </span>
</div>
<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
<script type="text/javascript">
    
    // Twitter
  !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');
  
  // Google + 
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/platform.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
  
  // StumbleUpon
   (function() {
    var li = document.createElement('script'); li.type = 'text/javascript'; li.async = true;
    li.src = ('https:' == document.location.protocol ? 'https:' : 'http:') + '//platform.stumbleupon.com/1/widgets.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(li, s);
  })();
   
   // Facebook
    window.fbAsyncInit = function() {
    // init the FB JS SDK
    FB.init({
      appId      : '501605429937282',                    // App ID from the app dashboard
      status     : true,                                 // Check Facebook Login status
      xfbml      : true                                  // Look for social plugins on the page
    });

    // Additional initialization code such as adding Event Listeners goes here
  };

  // Load the SDK asynchronously
  (function(){
     // If we've already installed the SDK, we're done
     if (document.getElementById('facebook-jssdk')) {return;}

     // Get the first script element, which we'll use to find the parent node
     var firstScriptElement = document.getElementsByTagName('script')[0];

     // Create a new script element and set its id
     var facebookJS = document.createElement('script'); 
     facebookJS.id = 'facebook-jssdk';

     // Set the new script's source to the source of the Facebook JS SDK
     facebookJS.src = '//connect.facebook.net/en_US/all.js';

     // Insert the Facebook JS SDK into the DOM
     firstScriptElement.parentNode.insertBefore(facebookJS, firstScriptElement);
   }());
    (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1&appId=546195308794054";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
  
  // Top Shinanigans
  var lockSocials = $(".solid_socials").offset().top;
  var socialsTop = $(".solid_socials").css('top');
  console.log(lockSocials);
  console.log(socialsTop);
    $(document).scroll(function() {
        if($(this).scrollTop() > lockSocials)
        {
           $('.solid_socials').css('top','55px');
        }
        else {
             $('.solid_socials').css('top',socialsTop);
        }
        })
  
  
  // Close The Widget
  $('#solid_hide').click(function() {
    $('.solid_socials').fadeOut("slow");
    })
  
</script>

